package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.api.model.Photos;
import com.example.api.model.Todo;

public class detalheTodo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_todo);

        Intent intent = getIntent();

        Todo todos = intent.getParcelableExtra("objTodo");

        TextView TextVi = findViewById(R.id.TextIDapi);
        TextVi.setText(todos.getUserId()+"");
        TextVi = findViewById(R.id.TextID);
        TextVi.setText(todos.getId()+"");
        TextVi = findViewById(R.id.TestString);
        TextVi.setText(todos.getTitle());
        CheckBox CheckB = findViewById(R.id.CheckB);
        CheckB.setChecked(todos.isCompleted());
    }
}