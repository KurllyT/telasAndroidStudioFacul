package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.api.model.Comments;
import com.example.api.model.Photos;
import com.example.api.model.Todo;

import org.w3c.dom.Text;

public class detalheComment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_lista);

        Intent intent = getIntent();

        Comments comments = intent.getParcelableExtra("objComments");

        TextView TextVi = findViewById(R.id.TextIDapi);
        TextVi.setText(comments.getPostId()+"");
        TextVi = findViewById(R.id.TextID);
        TextVi.setText(comments.getId()+"");
        TextVi = findViewById(R.id.TestString);
        TextVi.setText(comments.getName());
        TextVi = findViewById(R.id.TestString2);
        TextVi.setText(comments.getEmail());

    }
}