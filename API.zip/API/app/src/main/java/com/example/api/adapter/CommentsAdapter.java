package com.example.api.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.api.R;
import com.example.api.model.Comments;
import com.example.api.model.Photos;

import java.util.List;


public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.TodoViewHolder>{

    private List<Comments> listaComments;

    public  class TodoViewHolder extends RecyclerView.ViewHolder{
        public View viewComments;
        public TodoViewHolder(@NonNull View itemView) {
            super(itemView);
            this.viewComments = itemView;
        }
    }

    public CommentsAdapter(List<Comments> comments){
        this.listaComments = comments;
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_detalhe_post,parent,false);
        return new TodoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
        Comments comments = this.listaComments.get(position);

        TextView TextVi;
        //TextView TextVi = holder.viewTodo.findViewById(R.id.TextIDapi);
        //TextVi.setText(todos.getUserId()+"");
        //TextVi = holder.viewTodo.findViewById(R.id.TextID);
        //TextVi.setText(todos.getId()+"");
        TextVi = holder.viewComments.findViewById(R.id.TestString);
        TextVi.setText(comments.getName());
        TextVi = holder.viewComments.findViewById(R.id.TestString2);
        TextVi.setText(comments.getEmail());

    }

    @Override
    public int getItemCount() {
        return this.listaComments.size();
    }
}
