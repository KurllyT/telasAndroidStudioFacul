package com.example.api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.api.adapter.PhotosAdapter;
import com.example.api.adapter.TodoAdapter;
import com.example.api.model.Photos;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListaPhotos extends AppCompatActivity
        implements Response.ErrorListener,
        Response.Listener<JSONArray>{

    List<Photos> Photos =  new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_photos);

        // Volley
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://jsonplaceholder.typicode.com/photos";
        // Request de JsonArray da URL.

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                this, this);


        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest);
        Toast.makeText(this,"qtd:"+ Photos.size(),Toast.LENGTH_LONG).show();
    }

    // Volley
    @Override
    public void onResponse(JSONArray response) {
        try {

            for(int i = 0; i < response.length(); i++) {
                JSONObject json = response.getJSONObject(i);
                Photos obj = new Photos(json.getInt("albumId"),
                        json.getInt("id"),
                        json.getString("title"),
                        json.getString("url"),
                        json.getString("thumbnailUrl"));
                Photos.add(obj);
            }
            Toast.makeText(this,"qtd:"+Photos.size(),Toast.LENGTH_LONG).show();

            RecyclerView rv = findViewById(R.id.rvPhotos);
            LinearLayoutManager llm = new LinearLayoutManager(this);
            rv.setLayoutManager(llm);
            PhotosAdapter photosAdapter = new PhotosAdapter(Photos);
            rv.setAdapter(photosAdapter);
            /*
            Toast.makeText(this,"qtd:"+ Photos.size(),Toast.LENGTH_LONG).show();
            LinearLayout ll = findViewById(R.id.layoutVerical3);
            for(Photos obj1 : Photos) {
                Button bt = new Button(this);
                bt.setText(obj1.getTitle());
                bt.setTag(obj1);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Button btn = (Button) v;
                        Photos photos = (Photos) btn.getTag();
                        Intent intent = new Intent(getBaseContext(), detalhePhotos.class);
                        intent.putExtra("OBJphotos", photos);
                        startActivity(intent);
                        Toast.makeText((ListaPhotos.this), obj1.getId() + " - " + obj1.getTitle(), Toast.LENGTH_SHORT).show();
                    }
                });
                ll.addView(bt);
            }

             */


        } catch (JSONException e) {
            Log.e("erro",e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        String msg = error.getMessage();
        Toast.makeText(this.getApplicationContext(),"deu erro: "+msg,Toast.LENGTH_LONG).show();
    }
}
