package com.example.api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.api.adapter.CommentsAdapter;
import com.example.api.adapter.PhotosAdapter;
import com.example.api.model.Comments;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListaComments extends AppCompatActivity
        implements Response.ErrorListener,
        Response.Listener<JSONArray> {

    List<Comments> Comments =  new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_comments);

        // Volley
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://jsonplaceholder.typicode.com/comments";
        // Request de JsonArray da URL.

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                this, this);


        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest);
        Toast.makeText(this,"qtd:"+ Comments.size(),Toast.LENGTH_LONG).show();
    }

    // Volley
    @Override
    public void onResponse(JSONArray response) {
        try {

            for(int i = 0; i < response.length(); i++) {
                JSONObject json = response.getJSONObject(i);
                Comments obj = new Comments(json.getInt("postId"),
                        json.getInt("id"),
                        json.getString("name"),
                        json.getString("email"),
                        json.getString("body"));
                Comments.add(obj);

            }
            Toast.makeText(this,"qtd:"+Comments.size(),Toast.LENGTH_LONG).show();

            RecyclerView rv = findViewById(R.id.rvComments);
            LinearLayoutManager llm = new LinearLayoutManager(this);
            rv.setLayoutManager(llm);
            CommentsAdapter commentsAdapter = new CommentsAdapter(Comments);
            rv.setAdapter(commentsAdapter);
            /*
            Toast.makeText(this,"qtd:"+ Comments.size(),Toast.LENGTH_LONG).show();
            LinearLayout ll = findViewById(R.id.layoutVerical2);
            for(Comments obj1 : Comments) {
                Button bt = new Button(this);
                bt.setText(obj1.getName());
                bt.setTag(obj1);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Button btn = (Button) v;
                        Comments comments = (Comments) btn.getTag();
                        Intent intent = new Intent(getApplicationContext(), detalheComment.class);
                        intent.putExtra("objComments",comments);
                        startActivity(intent);
                        Toast.makeText((ListaComments.this), obj1.getId() + " - " + obj1.getName(), Toast.LENGTH_SHORT).show();
                    }
                });
                ll.addView(bt);
            }
            */

        } catch (JSONException e) {
            Log.e("erro",e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        String msg = error.getMessage();
        Toast.makeText(this.getApplicationContext(),"deu erro: "+msg,Toast.LENGTH_LONG).show();
    }
}