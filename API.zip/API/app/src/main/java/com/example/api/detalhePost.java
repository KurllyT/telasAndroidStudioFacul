package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.api.model.Photos;
import com.example.api.model.Post;

public class detalhePost extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_post);

        Intent intent = getIntent();

        Post posts = intent.getParcelableExtra("objPost");

        TextView TextVi = findViewById(R.id.TextIDapi);
        TextVi.setText(posts.getUserId()+"");
        TextVi = findViewById(R.id.TextID);
        TextVi.setText(posts.getId()+"");
        TextVi = findViewById(R.id.TestString);
        TextVi.setText(posts.getTitle());
        TextVi = findViewById(R.id.TestString2);
        TextVi.setText(posts.getBody());
    }
}