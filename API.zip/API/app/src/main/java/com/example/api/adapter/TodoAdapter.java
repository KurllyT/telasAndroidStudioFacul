package com.example.api.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.api.R;
import com.example.api.model.Todo;

import java.util.List;


public class TodoAdapter extends RecyclerView.Adapter<TodoAdapter.TodoViewHolder>{

    private List<Todo> listaTodos;
    private int layout;

    public  class TodoViewHolder extends RecyclerView.ViewHolder{
        public View viewTodo;
        public TodoViewHolder(@NonNull View itemView) {
            super(itemView);
            this.viewTodo = itemView;
        }
    }

    public TodoAdapter(List<Todo> todos, int layout){
        this.listaTodos = todos;
        this.layout = layout;
        if(this.layout == 0){
            this.layout = R.layout.layout;
        }
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(this.layout,parent,false);
        return new TodoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
        Todo todos = this.listaTodos.get(position);

        TextView TextVi;
        //TextView TextVi = holder.viewTodo.findViewById(R.id.TextIDapi);
        //TextVi.setText(todos.getUserId()+"");
        //TextVi = holder.viewTodo.findViewById(R.id.TextID);
        //TextVi.setText(todos.getId()+"");
        TextVi = holder.viewTodo.findViewById(R.id.TestString);
        TextVi.setText(todos.getTitle());
        CheckBox CheckB = holder.viewTodo.findViewById(R.id.CheckB);
        CheckB.setChecked(todos.isCompleted());

    }

    @Override
    public int getItemCount() {
        return this.listaTodos.size();
    }
}
