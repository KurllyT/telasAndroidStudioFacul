package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.api.model.Photos;

public class detalhePhotos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_lista);

        Intent intent = getIntent();

        Photos photos = intent.getParcelableExtra("OBJphotos");

        TextView TextVi = findViewById(R.id.TextIDapi);
        TextVi.setText(photos.getAlbumId()+"");
        TextVi = findViewById(R.id.TextID);
        TextVi.setText(photos.getId()+"");
        TextVi = findViewById(R.id.TestString);
        TextVi.setText(photos.getTitle());
        TextVi = findViewById(R.id.TestString2);
        TextVi.setText(photos.getUrl());
        TextVi = findViewById(R.id.TestString3);
        TextVi.setText(photos.getThumbnailUrl());
    }
}