package com.example.api.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.api.R;
import com.example.api.model.Photos;
import com.example.api.model.Todo;

import java.util.List;


public class PhotosAdapter extends RecyclerView.Adapter<PhotosAdapter.TodoViewHolder>{

    private List<Photos> listaPhotos;

    public  class TodoViewHolder extends RecyclerView.ViewHolder{
        public View viewPhotos;
        public TodoViewHolder(@NonNull View itemView) {
            super(itemView);
            this.viewPhotos = itemView;
        }
    }

    public PhotosAdapter(List<Photos> photos){
        this.listaPhotos = photos;
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_detalhe_photos,parent,false);
        return new TodoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
        Photos photos = this.listaPhotos.get(position);

        TextView TextVi;
        //TextView TextVi = holder.viewTodo.findViewById(R.id.TextIDapi);
        //TextVi.setText(todos.getUserId()+"");
        //TextVi = holder.viewTodo.findViewById(R.id.TextID);
        //TextVi.setText(todos.getId()+"");
        TextVi = holder.viewPhotos.findViewById(R.id.TestString);
        TextVi.setText(photos.getTitle());
        TextVi = holder.viewPhotos.findViewById(R.id.TestString2);
        TextVi.setText(photos.getThumbnailUrl());

    }

    @Override
    public int getItemCount() {
        return this.listaPhotos.size();
    }
}
